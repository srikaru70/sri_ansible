#!/bin/bash

echo -n "Enter Installation Directory:"
read install_dir



echo "#----------------------Starting mysql container------------#"

install_dir="$install_dir/snipeit"
snipeitapp_mysql="$install_dir/mysql"
snipeitapp_vol="$install_dir/app"


docker run --detach \
        --publish 6603:3306 \
        --restart=always \
        --name snipeit-mysql \
        --env-file=$install_dir/config/mysql.env \
        --volume $snipeitapp_mysql:/var/lib/mysql \
        mysql:5.6


sleep 60

docker ps -as


echo "#-------------------Starting App container-Wait for 1 minitue-----------------------#"

sleep 60


docker run --detach \
        --publish 8080:80 \
        --restart=always \
        --name snipeit-app \
        --volume $snipeitapp_vol:/var/lib/snipeit \
        --link  snipeit-mysql:mysql \
        --env-file=$install_dir/config/docker.env \
        docker.io/snipe/snipe-it:v4.1.13
sleep 60

docker ps -as

