#!/usr/bin/bash
SRC_YAML="/home/ansible/Ansible/aggr_creation"
export PATH=/usr/bin:$PATH

if [ -d $SRC_YAML ] ; then

   ansible-playbook --extra-vars="@$SRC_YAML/cluster_generic_setting_vserver_vars.yml" $SRC_YAML/aggre_create.yml


fi
