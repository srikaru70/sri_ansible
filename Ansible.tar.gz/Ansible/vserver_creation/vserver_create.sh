#!/usr/bin/bash
SRC_YAML="/home/ansible/Ansible/vserver_creation"
export PATH=/usr/bin:$PATH

if [ -d $SRC_YAML ] ; then

   ansible-playbook --extra-vars="@$SRC_YAML/cluster_generic_setting_vserver_vars.yml" $SRC_YAML/us01_svm_creation.yml
   sleep 60
   ansible-playbook --extra-vars="@$SRC_YAML/cluster_generic_setting_vserver_vars.yml" $SRC_YAML/us01cm_ls_mirror_create.yml


fi
