#!/bin/bash

echo ""
echo ""
echo ""


docker ps -as
docker stop snipeit-app snipeit-mysql
echo " Delete docker process"
docker rm snipeit-app snipeit-mysql
docker ps -as



