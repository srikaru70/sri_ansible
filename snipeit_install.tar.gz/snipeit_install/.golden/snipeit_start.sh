#!/bin/bash


echo "#-----------------Install the MYSQL and SNIPEIT Docker Image-------------------#"

echo ""


echo "-----------------Downloading mysql image-------------------#"
docker pull mysql:5.6
echo "#-----------------------------------------------------------#"
echo "downloading snipeit image"
docker pull snipe/snipe-it:v4.1.13

echo "#--------------Docker Image show-----------------------------#"

docker image list


echo "#--------------Start the Snipeit Installation---------------#"

echo "#---------- Set the Variables-------------------------------#"
base_dir="/home/devopadmin/dockerimage"
snipeit_mysql="$base_dir/snipeit_mysql"
snipeitapp_vol="$base_dir/snipeit_app"
host=$(hostname)

echo "Base directory  :$base_dir "
echo "MySQL directory :$snipeit_mysql "
echo "App Directory   :$snipeitapp_vol"
echo "HostName        :$host"

echo "#-----------------Stop and Remove existing process -------#"

docker ps -as

echo ""
echo ""
echo ""


docker stop snipeit-app snipeit-mysql

echo ""

echo " #-------------Delete docker process----------------------#"
docker rm snipeit-app snipeit-mysql

echo ""
echo ""

echo "#-----------------------Please standby --------------------#"

sleep 30
docker ps -as

echo "#----------------------Starting mysql container------------#"

docker run --detach \
        --publish 6603:3306 \
        --name snipeit-mysql \
        --env-file=$base_dir/snipeit_config/mysql.env \
        --volume $snipeit_mysql:/var/lib/mysql \
        mysql:5.6


sleep 60

docker ps -as


echo "#-------------------Starting App container-----------------------#"

sleep 60


docker run --detach \
        --publish 8080:80 \
        --name snipeit-app \
        --volume $snipeitapp_vol:/var/lib/snipeit \
        --link  snipeit-mysql:mysql \
        --env-file=$base_dir/snipeit_config/docker.env \
        docker.io/snipe/snipe-it:v4.1.13
sleep 60

docker ps -as

echo "#---------------------- Showing the docker process---------"

sleep 120

docker ps -as

echo "#------------------------------- Check the Website -------#"
echo ""
echo ""
wget -c http://$host:8080/

rm ./index.html

echo ""

echo "The Access url :  http://$host:8080/ "


echo   "#---------------End of Installation---------------------#"


