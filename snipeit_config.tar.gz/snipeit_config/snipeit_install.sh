#!/bin/bash
host=$(hostname)


echo " You are working on $host"



#echo " downloading mysql image"
#docker pull mysql:5.6

# echo "downloading snipeit image"
#dockr pull snipe-it:v4.1.13
echo "Set the external volume for docker container"
echo -n "Enter MYSQL DB location:"
read dbvol
echo -n "Enter SNIPEIT App location:" 
read app
snipeitapp_vol=$app
snipeit_mysql=$dbvol


echo  "MYSQL volume:$snipeit_mysql"
echo  "SNIPEIT_APP:$snipeitapp_vol"
echo "------------------------------------------------------------"

echo " downloading mysql image"
docker pull mysql:5.6
echo "------------------------------------------------------------"
echo "downloading snipeit image"
docker pull snipe/snipe-it:v4.1.13

echo "-----------------------------------------------------------"


echo "Starting mysql container"

docker run --detach \
        --publish 6603:3306 \
        --name snipeit-mysql \
        --env-file=$HOME/snipeit_config/mysql.env \
        --volume $snipeit_mysql:/var/lib/mysql \
        mysql:5.6

docker ps -as

echo "---------------------------------------------------------"

echo "Starting snipiet App"

docker run --detach \
        --publish 8080:80 \
        --name snipeit-app \
        --volume $snipeitapp_vol:/var/lib/snipeit \
        --link  snipeit-mysql:mysql \
        --env-file=$HOME/snipeit_config/docker.env \
        docker.io/snipe/snipe-it:v4.1.13
echo "--------------------------------------------------------"

echo " Showing the docker process"

docker ps -as

echo "---------------------------------------------------------"

echo " Check the Website "
wget -c http://$host:8080/

rm ./index.html
echo "The Access url :  http://$host:8080/ "


echo "--------------------------------------------------------"




