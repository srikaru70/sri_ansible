#!/usr/bin/perl 


use warnings;
use strict;
use threads;

my $log="/u/karu/disk_cleanup/nvidia_delete.txt";

my $admin = 'root';
my $usr = `whoami`;

if($usr !~m/root/) {
        print "Run this script as $admin exiting......\n";
        exit;
}

open(LOG,$log) || die "Cannot open a log file $log";

while(<LOG>) {
	chomp;	
	my $date = `date`;
	chomp($date);
	my ($data)=$_;
	$data =~ s/^\s+$//g;
	$data =~ s/\s+//g;
#	print "$date:Deletion is in progress $data\n";
#	print "$date:Listing  is in progress $data\n";

	if(-e $data) {
#	        print "$data:found\n";
#		print `ls -altr $data| awk '{print \$3,\$6,\$7,\$9}'\n`;
#		print `ls -ald $data`;
		print `du -sh $data`;
			if($? != 0) {
                                print "$date:command not executed please check $data\n";
                        }
	}
}
